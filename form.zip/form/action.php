<doctype <!DOCTYPE html>
<html>
<head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Page Title</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/all.css">

</head>
<body>
<div class="container">
<br><br><br>

<div class="row">
	<aside class="col-sm-4 offset-md-4 ">

<div class="card">
<article class="card-body">
	<h3 class="card-title text-center mb-4 mt-1"><?= @$_POST['lname']?> WELCOME TO EKASUWA</h3>
	<hr>
	<p class="text-success text-center">Please kindly enter Verification code  </p>
	<form action="action.php" method="POST">
	<div class="form-group">
	<div class="input-group">
		<div class="input-group-prepend">
		    <span class="input-group-text"> <i class="fa fa-lock"></i> </span>
		 </div>
		<input class="form-control" placeholder="Code" type="text" name="pin">
	</div> <!-- input-group.// -->
	</div> <!-- form-group// -->
	<div class="form-group">
	
	</div> <!-- form-group// -->
	<div class="form-group">
	<button type="submit" class="btn btn-danger btn-block" name="vfy"> Verify</button>
	</div> <!-- form-group// -->

	</form>
</article>
</div> <!-- card.// -->

	</aside> <!-- col.// -->
</div> <!-- row.// -->

</div> 
<!--container end.//-->


</body>
</html>

<?php
$con = mysqli_connect("localhost","root" ,"","ruser") or die($error);


      
	@$check=$_GET['fname'];

        if(isset($_POST['vfy'])){
                @$pin=$_POST['pin'];
                $vry="SELECT * FROM users WHERE `code`='$pin'";
                $query = mysqli_query($con,$vry);
		$numrows = mysqli_num_rows($query);
		
                if($numrows > 0)
                {
			echo "<script>window.alert('Success')</script>";
                }else{
			echo "<script>window.alert('failed')</script>";
		}
         

        }


?>