
<doctype <!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Page Title</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/all.css">

</head>
<body>
	
<div class="container">
<br>

<div class="row justify-content-center">
<div class="col-md-6">
<div class="card">
<header class="card-header">
	
	<h4 class="card-title mt-2" style="text-align:center;">SIGN UP FORM</h4>
</header>
<article class="card-body">
<form action="index.php" method="post">
	<div class="form-row">
		<div class="col form-group">
			<label>First name </label>   
		  	<input type="text" class="form-control" placeholder="" name="fname">
		</div> <!-- form-group end.// -->
		<div class="col form-group">
			<label>Last name</label>
		  	<input type="text" class="form-control" placeholder=" " name="lname">
		</div> <!-- form-group end.// -->
	</div> <!-- form-row end.// -->
	<div class="form-group">
		<label>Email address</label>
		<input type="email" class="form-control" placeholder="" name="email">
		<small class="form-text text-muted">We'll never share your email with anyone else.</small>
	</div> <!-- form-group end.// -->
	<div class="form-group">
			<label class="form-check form-check-inline">
		  <input class="form-check-input" type="radio" name="gender" value="male">
		  <span class="form-check-label"> Male </span>
		</label>
		<label class="form-check form-check-inline">
		  <input class="form-check-input" type="radio" name="gender" value="female">
		  <span class="form-check-label"> Female</span>
		</label>
	</div> <!-- form-group end.// -->
	<div class="form-row">
		<div class="form-group col-md-6">
		  <label>Phone</label>
		  <input type="text" class="form-control" name="phone">
		</div> <!-- form-group end.// -->
		<div class="form-group col-md-6">
		  <label>Type</label>
		  <select id="inputState" class="form-control" name="type">
		    <option> Choose...</option>
		      <option value="Seller">Seller</option>
		      <option value = "Buyer">Buyer</option>
		     
		  </select>
		</div> <!-- form-group end.// -->
	</div> <!-- form-row.// -->
	<div class="form-group">
		<label>State</label>
	    <input class="form-control" type="text" name="state">
	</div> <!-- form-group end.// -->  
    <div class="form-group">
        <button type="submit" class="btn btn-danger btn-block" name="submit">Submit</button>
    </div> <!-- form-group// -->      
   
</form>
</article> <!-- card-body end .// -->

</div> <!-- card.// -->
</div> <!-- col.//-->

</div> <!-- row.//-->


</div> 
<!--container end.//-->





</body>
</html>

<?php
$error = 'Failed';
$con = mysqli_connect("localhost","root" ,"","ruser") or die($error);

if (isset($_POST['submit'])) {

        $code = substr($_POST['phone'], 4, 10);
		$fname=$_POST['fname'];
		$lname=$_POST['lname'];
		$mail=$_POST['email'];		
		$phone=$_POST['phone'];
		$btype=$_POST['type'];
		$state=$_POST['state'];
		
		$querry= "INSERT INTO users(`first_name`,`last_name`,`email`,`phone`,`type`,`state`,`code`) VALUES('$fname','$lname','$mail','$phone','$btype','$state','$code') ";
		$run=mysqli_query($con, $querry);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,"http://www.smslive247.com/http/index.aspx");
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS,"cmd=sendquickmsg&owneremail=timtech4u@gmail.com&subacct=EKASUWA&subacctpwd=p@55w0rd&message=Welcome to eKasuwa, thanks for signing up, Verfiy you account using: {$code} Thanks&sender=DND_BYPASSeKasuwa&sendto=$phone&msgtype=0&");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $server_output = curl_exec ($ch);
		curl_close ($ch);
		
		header('Location: http:/form/action.php?fname='.$_POST['fname']);
        
}
?>
